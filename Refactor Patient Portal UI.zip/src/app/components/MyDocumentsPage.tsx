import { useState } from 'react';
import { motion } from 'motion/react';
import { Home, Edit, FileText, Moon, Sun, MessageCircle, User, ArrowLeft, Search, Folder, ClipboardCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/app/components/ui/input';
import { Card } from '@/app/components/ui/card';
import { useDarkMode } from '@/app/components/DarkModeContext';

export function MyDocumentsPage() {
  const navigate = useNavigate();
  const { darkMode, toggleDarkMode } = useDarkMode();
  const [activeTab, setActiveTab] = useState<'clinical' | 'completed'>('clinical');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-600 to-purple-700 text-white p-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-lg">🔗</span>
            </div>
            <h1 className="text-lg font-bold">TensorLinks</h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/dashboard/summary')}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="Home"
            >
              <Home className="w-5 h-5" />
            </button>
            <button
              onClick={() => navigate('/profile-manage')}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="Edit Profile"
            >
              <Edit className="w-5 h-5" />
            </button>
            <button className="p-2 bg-white/20 rounded-lg transition-colors" title="Documents">
              <FileText className="w-5 h-5" />
            </button>
            <button
              onClick={toggleDarkMode}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              title="Toggle Dark Mode"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button className="p-2 hover:bg-white/20 rounded-lg transition-colors" title="Messages">
              <MessageCircle className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-white/20 rounded-lg transition-colors" title="Account">
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-6xl mx-auto p-6">
        {/* Back Button */}
        <button
          onClick={() => navigate('/dashboard/summary')}
          className="mb-6 w-12 h-12 bg-purple-600 hover:bg-purple-700 text-white rounded-full flex items-center justify-center shadow-lg transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        {/* Documents Card */}
        <Card className="p-6">
          <div className="space-y-6">
            {/* Title and Search */}
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">My Documents</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Search Documents</p>
              
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder={activeTab === 'clinical' ? 'Search by name, type, or category' : 'Search Documents'}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full"
                />
              </div>
            </div>

            {/* Tabs */}
            <div className="border-b border-gray-200 dark:border-gray-700">
              <div className="flex gap-8">
                <button
                  onClick={() => setActiveTab('clinical')}
                  className={`pb-3 px-1 font-medium text-sm transition-colors relative ${
                    activeTab === 'clinical'
                      ? 'text-purple-600 dark:text-purple-400'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  Clinical Documents
                  {activeTab === 'clinical' && (
                    <motion.div
                      layoutId="documentTab"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600 dark:bg-purple-400"
                    />
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('completed')}
                  className={`pb-3 px-1 font-medium text-sm transition-colors relative ${
                    activeTab === 'completed'
                      ? 'text-purple-600 dark:text-purple-400'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  Completed Forms
                  {activeTab === 'completed' && (
                    <motion.div
                      layoutId="documentTab"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600 dark:bg-purple-400"
                    />
                  )}
                </button>
              </div>
            </div>

            {/* Tab Content */}
            <div className="py-12">
              {activeTab === 'clinical' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 mx-auto mb-4 text-gray-400 dark:text-gray-500">
                    <Folder className="w-full h-full" />
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">No clinical documents found</p>
                </motion.div>
              )}

              {activeTab === 'completed' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 mx-auto mb-4 text-gray-400 dark:text-gray-500">
                    <ClipboardCheck className="w-full h-full" />
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">No completed forms found</p>
                </motion.div>
              )}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}