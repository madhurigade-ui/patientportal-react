import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, ShieldCheck, Smartphone } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/app/components/ui/input-otp';

export function OTPVerificationPage() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerify = () => {
    setIsVerifying(true);
    setTimeout(() => {
      navigate('/dashboard/summary');
    }, 1000);
  };

  const handleBack = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-8 text-white">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="flex items-center justify-center mb-4"
            >
              <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl">
                <ShieldCheck className="w-12 h-12" />
              </div>
            </motion.div>
            <h2 className="text-2xl font-bold text-center mb-2">Phone Number Verification</h2>
            <p className="text-purple-100 text-center">
              Secure your account with a One-Time Password (OTP)
            </p>
          </div>

          {/* Form */}
          <div className="p-8">
            <div className="space-y-6">
              {/* OTP Code Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
                <Smartphone className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm text-blue-900 font-medium">Code sent to +1(945)551234</p>
                  <p className="text-xs text-blue-700 mt-1">
                    Please check your phone for the verification code
                  </p>
                </div>
              </div>

              {/* OTP Input */}
              <div className="space-y-4">
                <label className="text-gray-700 font-medium block text-center">
                  Enter Verification Code
                </label>
                <div className="flex justify-center">
                  <InputOTP
                    maxLength={6}
                    value={otp}
                    onChange={(value) => setOtp(value)}
                  >
                    <InputOTPGroup className="gap-2">
                      <InputOTPSlot index={0} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                      <InputOTPSlot index={1} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                      <InputOTPSlot index={2} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                      <InputOTPSlot index={3} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                      <InputOTPSlot index={4} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                      <InputOTPSlot index={5} className="w-12 h-14 text-xl border-2 border-gray-300 rounded-xl" />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
              </div>

              {/* Resend Code */}
              <div className="text-center">
                <button className="text-sm text-purple-600 hover:text-purple-700 font-medium hover:underline">
                  Didn't receive code? Resend
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleBack}
                  variant="outline"
                  className="flex-1 h-12 rounded-xl border-2 hover:bg-gray-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={handleVerify}
                  disabled={otp.length !== 6 || isVerifying}
                  className="flex-1 h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl font-semibold shadow-lg disabled:opacity-50"
                >
                  {isVerifying ? 'Verifying...' : 'Verify Code'}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-gray-600 mt-6 text-sm"
        >
          Powered by TensorLinks - AI for Healthcare
        </motion.p>
      </motion.div>
    </div>
  );
}