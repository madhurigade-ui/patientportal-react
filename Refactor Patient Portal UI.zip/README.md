
  # Refactor Patient Portal UI

  This is a code bundle for Refactor Patient Portal UI. The original project is available at https://www.figma.com/design/iLMnQJU1CTQwOBLAZgslTR/Refactor-Patient-Portal-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  